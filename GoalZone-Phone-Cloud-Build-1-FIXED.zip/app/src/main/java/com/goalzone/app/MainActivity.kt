package com.goalzone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val bg = Color(0xFF08110E)
private val panel = Color(0xFF14231C)
private val green = Color(0xFF39D98A)
private val muted = Color(0xFFA2B4AA)

data class Match(val league: String, val home: String, val away: String, val score: String, val time: String, val live: Boolean)

private val demo = listOf(
    Match("Premier League", "Arsenal", "Chelsea", "2 - 1", "67'", true),
    Match("La Liga", "Real Madrid", "Sevilla", "1 - 0", "52'", true),
    Match("Serie A", "Inter", "Juventus", "—", "19:45", false),
    Match("Bundesliga", "Bayern Munich", "Borussia Dortmund", "—", "20:30", false),
    Match("Champions League", "Barcelona", "Paris Saint-Germain", "—", "Tomorrow", false)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoalZone() }
    }
}

@Composable
fun GoalZone() {
    var tab by remember { mutableStateOf("Scores") }
    var search by remember { mutableStateOf("") }
    var favourites by remember { mutableStateOf(setOf("Arsenal", "Real Madrid")) }
    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel, primary = green)) {
        Scaffold(
            containerColor = bg,
            bottomBar = {
                NavigationBar(containerColor = panel) {
                    listOf("Scores", "Fixtures", "Watch", "Leagues", "Saved").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = {
                                Icon(when(item) {
                                    "Scores" -> Icons.Default.SportsSoccer
                                    "Fixtures" -> Icons.Default.CalendarMonth
                                    "Watch" -> Icons.Default.LiveTv
                                    "Leagues" -> Icons.Default.EmojiEvents
                                    else -> Icons.Default.Star
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = green, selectedTextColor = green, indicatorColor = Color(0xFF254333), unselectedIconColor = muted, unselectedTextColor = muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SportsSoccer, null, tint = green, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GOALZONE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp, letterSpacing = 1.5.sp)
                        Text("FOOTBALL, ALL IN ONE PLACE", color = muted, fontSize = 9.sp)
                    }
                    Icon(Icons.Default.NotificationsNone, null, tint = Color.White)
                }
                when(tab) {
                    "Scores" -> {
                        Text("Match centre", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp))
                        Text("Follow football around the world", color = muted, modifier = Modifier.padding(horizontal = 18.dp))
                        OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth().padding(16.dp), placeholder = { Text("Search teams or leagues") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                        LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                            items(demo.filter { search.isBlank() || it.home.contains(search, true) || it.away.contains(search, true) || it.league.contains(search, true) }) { match ->
                                MatchTile(match, favourites) { team ->
                                    favourites = if(team in favourites) favourites - team else favourites + team
                                }
                            }
                            item { Text("Demo scores only — connect a licensed data provider for real-time scores.", color = muted, fontSize = 11.sp, modifier = Modifier.padding(18.dp)) }
                        }
                    }
                    "Fixtures" -> SimplePage("Fixtures", "Upcoming and completed matches", "Match schedules will appear here when the football data feed is connected.")
                    "Watch" -> SimplePage("Where to watch", "Official broadcasters worldwide", "Broadcast rights vary by country and competition. This section will list verified TV channels and authorised streaming links.")
                    "Leagues" -> SimplePage("Competitions", "Follow your favourite leagues", "Premier League\nLa Liga\nSerie A\nBundesliga\nLigue 1\nUEFA Champions League\nUEFA Europa League")
                    else -> SimplePage("Saved teams", "Your favourite clubs", if(favourites.isEmpty()) "No saved teams yet." else favourites.joinToString("\n"))
                }
            }
        }
    }
}

@Composable
fun MatchTile(match: Match, favourites: Set<String>, onToggle: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.league.uppercase(), color = muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                if(match.live) {
                    Box(Modifier.background(Color(0xFF512B2B), CircleShape).padding(horizontal = 9.dp, vertical = 4.dp)) {
                        Text("LIVE ${match.time}", color = Color(0xFFFF8888), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                } else Text(match.time, color = muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.home, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(match.score, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text(match.away, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                IconButton(onClick = { onToggle(match.home); onToggle(match.away) }) {
                    Icon(Icons.Default.Star, null, tint = if(match.home in favourites) green else muted)
                }
            }
        }
    }
}

@Composable
fun SimplePage(title: String, subtitle: String, body: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
            Text(body, color = Color.White, modifier = Modifier.padding(18.dp), lineHeight = 25.sp)
        }
    }
}
